
<div class="container tresc_zalogowany_jako" style="clear: both;">
	<?php  echo 'Witaj <i class="material-icons">account_box</i> <b>'.$_SESSION['sesja_uzyt']['zalogowany'].'</b>'; ?>
</div>