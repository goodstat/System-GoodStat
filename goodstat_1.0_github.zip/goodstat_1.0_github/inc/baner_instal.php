<div class="container baner_instal">
	<div class="row">
		<div class="col-md-6 col-xs-12">
			<img src="images/logo-goodstat.png" class="img-fluid navbar-brand animated bounceInLeft" alt="Logo GoodStat-u" />
		</div>
		<div class="hidden-xs d-none d-md-block col-md-6 col-xs-12 animated bounceInRight" id="tekst-baner">
			<blockquote class="blockquote text-right">
				<span class="animated pulse">"Odpowiednia analiza danych z Systemu GoodStat, może przyczynić się do zwiększenia wizyt na Twojej stronie internetowej"</span>
				<footer class="blockquote-footer">autor GoodStat-u</footer>
			</blockquote>
		</div>
	</div>
</div>