<!-- regulamin -->
<div class="modal fade" id="regulamin_stopka">
    <div class="modal-dialog modal-xl">
		<div class="modal-content">
      
			<!-- Modal Header -->
			<div class="modal-header">
				<h4 class="modal-title">Regulamin</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div>
        
			<!-- Modal body -->
			<div class="modal-body">
				
<?php
	include('regulamin_tresc.php');
?>
				
			</div>
        
			<!-- Modal footer -->
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
			</div>
        
		</div>
    </div>
</div>
<!-- / regulamin -->