
	<img src="images/pudelko_700x700.png" class="img-fluid rounded mx-auto d-block p-2" alt="logo GoodStat">