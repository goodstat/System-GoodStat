<?php
	include('wyslij_1.php');	//usun system
	include('wyslij_2.php');	//usun przegladarke
	include('wyslij_3.php');	//usun rozdzielczosc
	include('wyslij_4.php');	//usun kolor
	include('wyslij_5.php');	//usun jezyk
	include('wyslij_6.php');	//usun podstrone
	include('wyslij_7.php');	//usun historie (reset)
	include('wyslij_8.php');	//usun zrodlo
	include('wyslij_9.php');	//usun boot-a	
	include('wyslij_10.php');	//zmiana hasla
	include('wyslij_11.php');	//usun logi (reset)
	include('wyslij_12.php');	//reset hasla